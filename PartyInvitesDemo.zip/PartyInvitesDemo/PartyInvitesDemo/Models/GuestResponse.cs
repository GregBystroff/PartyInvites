﻿using System.ComponentModel.DataAnnotations;

namespace PartyInvitesDemo.Models
{
    public class GuestResponse
    {
        //   F i e l d s   and   P r o p e r t i e s
        [Required(ErrorMessage = "A name is required.")]
        public string Name { get; set; } // property

        [Required(ErrorMessage = "Please enter your phone.")]
        public string Phone { get; set; } // property

        public string Password { get; set; } // property

        [Required(ErrorMessage = "An email is required.")]
        public string Email { get; set; } // property

        // [Required(ErrorMessage = "Please let us know if you will be there or not.")]
        public bool? WillAttend { get; set; } // property

        public char Gender{ get; set; } // property

        //   C o n s t r u c t o r s 

        //   M e t h o d s 
        // public void GetPhone(string phone)
        // {
        //     this.Phone = phone;
        // }
    }
}
