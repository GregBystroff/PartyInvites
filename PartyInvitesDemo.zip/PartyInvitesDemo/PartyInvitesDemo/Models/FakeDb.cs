﻿namespace PartyInvitesDemo.Models
{
    public class FakeDb
    {
        //   F i e l d s   a n d   P r o p e r t i e s 

        private static GuestResponse[] Responses = new GuestResponse[10];
        private static int ResponseCount = 0;

        //   C o n s t r u c t o r s

        //   M e t h o d s
        public static void AddResponse(GuestResponse response)
        {
            Responses[ResponseCount] = response;
            ResponseCount++;
        } // end AddResponse

        public static int GetResponseCount()
        {
            return ResponseCount;
        }

        public static GuestResponse[] GetResponses()
        {
            return Responses;
        }

        public static GuestResponse[] AllResponses()
        {
            return Responses;
        }

       // public static int GetFemaleCount()
       // { // LInQ -- language integrated query  -- wont work until we have a database
       //     // return responses.Where(r => r != null && r.Gender == 'F').Count();
       //
       // }
       //
       // public static int GetMaleCount()
       // { // LInQ -- language integrated query
       //     // return responses.Where(r => r != null && r.Gender == 'M').Count();

        //}
    }
}
