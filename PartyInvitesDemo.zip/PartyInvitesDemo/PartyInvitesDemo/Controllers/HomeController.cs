﻿using Microsoft.AspNetCore.Mvc;
using PartyInvitesDemo.Models;

namespace PartyInvitesDemo.Controllers
{
    public class HomeController : Controller
    {

        public IActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public IActionResult RsvpForm()
        {
            return View();
        }

        [HttpPost]
        public IActionResult RsvpForm(GuestResponse gr)
        {
            if (ModelState.IsValid)
            {
                FakeDb.AddResponse(gr);
                // int males = FakeDb.GetMaleCount();
                // put a sleep statement here .. related to web pages 
                System.Threading.Thread.Sleep(200); // sleep for 2 seconds
                return View("Thanks", gr);
            }
            return View(gr);
        }

        public IActionResult Privacy()
        {
            return View();
        }

        public IActionResult ListResponses()
        {
            GuestResponse[] gr = FakeDb.AllResponses(); // changing this such that it is the length of only valid responses.
            ViewBag.Count = FakeDb.GetResponseCount();
            return View(gr);
        }

    }
}
